import { createContext } from "react";

const AuthContext = createContext();
export default AuthContext;

