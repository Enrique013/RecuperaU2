import React, { useContext } from 'react'
import SignInPage from '../modules/auth/SignInPage';
import AuthContext from '../config/context/auth-context';
import { Route, RouterProvider, createBrowserRouter, createRoutesFromElements } from 'react-router-dom';
import Error from '../modules/temp/Error';
import AdminLayouts from '../modules/admin/AdminLayouts';

function AppRouter() {
  const {user} = useContext(AuthContext);
    const router  = createBrowserRouter(
      createRoutesFromElements(
        <>
        
        {
          //publico
        }
        {
          user.signed ? (
          <>
          <Route path='/' element={<AdminLayouts />}>
              {user.role === 'ADMIN_ROLE' && <Route path='/admin' element={<>ROLE: ADMIN</>} />}
              {user.role === 'USER_ROLE' && <Route path='/user' element={<>ROLE: USER</>} />}
              {user.role === 'CLIENT_ROLE' && <Route path='/client' element={<>ROLE: CLIENT</>} />}
            </Route>
          
          </>
          ) : <Route path='/' element={<SignInPage/>}/>
        }
        <Route path='/*' element={<Error/>}/>
        </>
      )
    
  )
  return <RouterProvider router={router}/>
}

export default AppRouter